<?php
session_start();
?>

<html>
<head>
<style>
.hov1:hover
{
	background-color:red;
	color:white;
}
.hov:hover
{
	background-color:grey;
}
#myDIV {
    width: 300px;
    height: 200px;
    background: red;
    -webkit-animation: mymove 5s infinite; /* Chrome, Safari, Opera */
    animation: mymove 5s infinite;
}

@-webkit-keyframes mymove {
    50% {background-color: white;}
}

/* Standard syntax */
@keyframes mymove {
    50% {background-color: white;}
}
</style>

    <script> 
	function disableB()
	{
		var bn4=document.getElementById("b4").value;
		var bn8=document.getElementById("b8").value;
		var bn12=document.getElementById("b12").value;
		var bn16=document.getElementById("b16").value;
		var bn20=document.getElementById("b20").value;
		var bn24=document.getElementById("b24").value;
		var bn28=document.getElementById("b28").value;
		var bn32=document.getElementById("b32").value;
		var bn36=document.getElementById("b36").value;
		var bn40=document.getElementById("b40").value;
		
		
		if(bn4==0||bn8==0||bn12==0||bn16==0||bn20==0||bn24==0||bn28==0||bn32==0||bn36==0||bn40==0)
			document.getElementById("next").disabled=true;
return false;		
	}
	

	function s1() {
		
       window.location.href="ProductView.php";
        }
      function demo1(b1) {
		
    var elem = document.getElementById("b1").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		 function demo2(b2) {
		
    var elem = document.getElementById("b2").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		function demo3(b3) {
		
    var elem = document.getElementById("b3").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo4(b4) {
		
    var elem = document.getElementById("b4").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo5(b5) {
		
    var elem = document.getElementById("b5").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo6(b6) {
		
    var elem = document.getElementById("b6").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		function demo7(b7) {
		
    var elem = document.getElementById("b7").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		function demo8(b8) {
		
    var elem = document.getElementById("b8").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		 
		function demo9(b9) {
		
    var elem = document.getElementById("b9").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo10(b10) {
		
    var elem = document.getElementById("b10").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		function demo11(b11) {
		
    var elem = document.getElementById("b11").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo12(b12) {
		
    var elem = document.getElementById("b12").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo13(b13) {
		
    var elem = document.getElementById("b13").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo14(b14) {
		
    var elem = document.getElementById("b14").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo15(b15) {
		
    var elem = document.getElementById("b15").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo16(b16) {
		
    var elem = document.getElementById("b16").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo17(b17) {
		
    var elem = document.getElementById("b17").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo18(b18) {
		
    var elem = document.getElementById("b18").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo19(b19) {
		
    var elem = document.getElementById("b19").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo20(b20) {
		
    var elem = document.getElementById("b20").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo21(b21) {
		
    var elem = document.getElementById("b21").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo22(b22) {
		
    var elem = document.getElementById("b22").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo23(b23) {
		
    var elem = document.getElementById("b23").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo24(b24) {
		
    var elem = document.getElementById("b24").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo25(b25) {
		
    var elem = document.getElementById("b25").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo26(b26) {
		
    var elem = document.getElementById("b26").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo27(b27) {
		
    var elem = document.getElementById("b27").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo28(b28) {
		
    var elem = document.getElementById("b28").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo29(b29) {
		
    var elem = document.getElementById("b29").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo30(b30) {
		
    var elem = document.getElementById("b30").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo31(b31) {
		
    var elem = document.getElementById("b31").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo32(b32) {
		
    var elem = document.getElementById("b32").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo33(b33) {
		
    var elem = document.getElementById("b33").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo34(b34) {
		
    var elem = document.getElementById("b34").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo35(b35) {
		
    var elem = document.getElementById("b35").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo36(b36) {
		
    var elem = document.getElementById("b36").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo37(b37) {
		
    var elem = document.getElementById("b37").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo38(b38) {
		
    var elem = document.getElementById("b38").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo39(b39) {
		
    var elem = document.getElementById("b39").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
		function demo40(b40) {
		
    var elem = document.getElementById("b40").value;

       window.location.href="display.php?value="+elem;
	   return false;
        }
		
    </script>
    </head>
<?php include("header.php")?>

<body background="b.png">
<form method="post">

<?php
include("connect.php");

//session_start();
 $subj = ! empty($_SESSION['uid']) ? $_SESSION['uid'] : ' ';
		 $_SESSION['uid']= $subj; 
 $uid= $_SESSION['uid'];
//$uid= $_SESSION['uid'];

$subj = ! empty($_SESSION['comp']) ? $_SESSION['comp'] : ' ';
		 $_SESSION['comp']= $subj; 
$comp=$_SESSION['comp'];

include("menu.php");
$con= new mysqli("localhost","root","","furniture");
?>

<table align="center">
<tr><td rowspan="3">
</br></br>
<div id="myDIV" class="intabular" style="width:100%;height:auto;background-color:white; border:2px solid grey;">

<label><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enter Category</h3></label>
&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select input type="text" name="cat" width="200%" >
<?php if (isset($_POST['cat']))
 {
	  echo "<option>".$_POST['cat']."</option>";
  
 }
 else
 {
  
  
    }
 ?>
<option>--select--</option>
<?php
 $sql5="select distinct catg from product";


  //$cnt=$cnt+1;
 $res = $con->query($sql5);
while($row = $res->fetch_assoc()) 
{?>
	<option value="<?php echo $row['catg'] ?>"/><?php echo $row['catg'] ?></option>
 
	<?php }
?>



</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" value="Search" name="s1" onClick="s1()">
<?php

 if(isset($_POST['s1']))
 {
	 $comp=$_POST['cat'];
	 $_SESSION['comp']=$comp;
    $sql="select id,img,name from product where catg='$comp'";
	}
 else
 {

 
	 $sql="select id,img,name from product";
 }

 
/* if(isset($_POST['next']))
 {  
if(!empty($_SESSION['comp']))
    $var=$_SESSION['comp'];
         if(empty($_SESSION['a'])) 
	          $_SESSION['a'] = 12;

	$cnt =  $_SESSION['a'];
	
	if(empty($_SESSION['comp']))
	$sql="select id,img,name from product limit $cnt,12";
else
	$sql="select id,img,name from product where catg='$var' limit $cnt,12";
		if ($result=mysqli_query($con,$sql))
		{
			// Return the number of rows in result set
			$rowcount=mysqli_num_rows($result);
		}
		$cnt =  $_SESSION['a']+12;
				 
		if($_SESSION['a']>=$rowcount) 
			$cnt = 12;
		
	$_SESSION['a'] =  $cnt; 
 
 }
 
 if(isset($_POST['prv']))
 {  
if(!empty($_SESSION['comp']))
		$var1=$_SESSION['comp'];

		if(empty($_SESSION['a'])||$_SESSION['a']<=12) 
				$_SESSION['a'] = 12;
 
	$cnt =  $_SESSION['a']-12;
	
	if(empty($_SESSION['comp']))
	$sql="select id,img,name from product limit $cnt,12";
else
	$sql="select id,img,name from product where catg='$var1' limit $cnt,12";
		if ($result=mysqli_query($con,$sql))
		{
			// Return the number of rows in result set
			$rowcount=mysqli_num_rows($result);
		}
		if($_SESSION['a']>=$rowcount) 
			$_SESSION['a'] = $_SESSION['a']-12;
		else
			$cnt =  $_SESSION['a']-12;
		
 $_SESSION['a'] =  $cnt; 
 }*/
 ?>
</select>
</br></br></br>
<label><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sort By Price</h3></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<select name="cat1" width="200%">
<?php if (isset($_POST['cat1']))
 {
	  echo "<option>".$_POST['cat1']."</option>";
  
 }
 else
 {
  
  
    }
 ?>

<option>--Select--</option>
<?php
 $sql5="select distinct catg from product";


  //$cnt=$cnt+1;
 $res = $con->query($sql5);
while($row = $res->fetch_assoc()) 
{?>
	<option value="<?php echo $row['catg'] ?>"/><?php echo $row['catg'] ?></option>

	<?php }
?>
</select></br></br>
&nbsp;&nbsp;&nbsp;<input type="number" name="t2" placeholder="From" value="<?php if (isset($_POST['t2'])) { echo $_POST['t2']; }  ?>"/></br></br>
&nbsp;&nbsp;&nbsp;<input type="number" name="t3" placeholder="To" value="<?php if (isset($_POST['t3'])) { echo $_POST['t3']; }  ?>"/></br></br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" value="Sort" name="s2"/></br></br></br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td>
</form>
<td>
<table><tr>
<td rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr></table></td>
<td>
<table  border="1" cellspacing="0" cellpadding="0" bgcolor="white"><tr><td class="hov">
<?php

if(isset($_POST['s2']))
 {
	 $comp=$_POST['cat1'];
	 $frm=$_POST['t2'];
	 $to=$_POST['t3'];
	$sql="select id,img,name from product where catg='$comp' and price between $frm and $to";
 }



  //$cnt=$cnt+1;
 $result = $con->query($sql);
 echo "<center>";  
while($row = $result->fetch_assoc()) 
{
	STATIC $i=1;
	if($i==1)
	{
          $image = $row['img'];
          ?><img id="i1" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		  		<button class="hov1" id="b1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo1(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
<?php }
	if($i==2)
	{
		$image = $row['img'];
         ?><td align="center" class="hov"><img id="i2" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		        <button id="b2" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo2(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
<?php }

if($i==3)
	{
		$image = $row['img'];
         ?><td align="center" class="hov"><img id="i3" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b3" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo3(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
<?php }
if($i==4)
	{
		$image = $row['img'];
         ?><td  align="center" class="hov"><img id="i4" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b4" class="hov1" value="<?php echo $row['id'];?>" style="border:white ;"  onClick="return demo4(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		 
	<?php }
if($i==5)
	{
		$image = $row['img'];
         ?><tr><td align="center" class="hov"><img id="i5" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b5" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo5(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
		 <br/><br/>
	<?php }
	
	if($i==6)
	{
		$image = $row['img'];
         ?><td align="center" class="hov"><img id="i6" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b6" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo6(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
	<?php }
	
	if($i==7)
	{
		$image = $row['img'];
         ?><td align="center" class="hov"><img id="i7" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b7" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo7(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
	<?php }
	
	if($i==8)
	{
		$image = $row['img'];
         ?><td align="center" class="hov"><img id="i8" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b8" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo8(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		 
	<?php }
	
	if($i==9)
	{
		$image = $row['img'];
         ?><tr><td align="center" class="hov"><img id="i9" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b9" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo9(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
	<?php }
	
	if($i==10)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i10" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b10" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo10(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==11)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i11" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b11" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo11(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		 
	<?php }
	
	if($i==12)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i12" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b12" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo12(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==13)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i13" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b13" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo13(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==14)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i14" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b14" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo14(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==15)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i15" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b15" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo15(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==16)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i16" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b16" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo16(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==17)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i17" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b17" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo17(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==18)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i18" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b18" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo18(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==19)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i19" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b19" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo19(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==20)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i20" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b20" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo20(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==21)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i21" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b21" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo21(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==22)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i22" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b22" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo22(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==23)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i23" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b23" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo23(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==24)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i24" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b24" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo24(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==25)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i25" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b25" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo25(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==26)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i26" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b26" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo26(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==27)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i27" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b27" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo27(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==28)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i28" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b28" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo28(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==29)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i29" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b29" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo29(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==30)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i30" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b30" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo30(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==31)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i31" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b31" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo31(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==32)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i32" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b32" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo32(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==33)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i33" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b33" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo33(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==34)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i34" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b34" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo34(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==35)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i35" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b35" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo35(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==36)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i36" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b36" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo36(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	
	if($i==37)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i37" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b37" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo37(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==38)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i38" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b38" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo38(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==39)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i39" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b39" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo39(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
	<?php }
	
	if($i==40)
	{
		$image = $row['img'];
         ?><td class="hov" align="center"><img id="i40" src="images/<?php echo $row['img']; ?>" height="140" width="170"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</br>
		 <button id="b40" class="hov1" style="border:white ;" value="<?php echo $row['id'];?>" onClick="return demo40(this.id)"><b><u><i><?php echo $row['name'];?></i></u></b></button></br></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
		
	<?php }
	$i=$i+1;
}

?>
</td></tr>
</table></table><center>
<!--<table><tr><td colspan="3">      
<input type="image" src="next.png" height="112px" width="128px" id="next" name="next" value="Next" />


<input type="image" src="prev.png" height="112px" width="128px" name="prv" value="Prev" />
</td></tr></table></center>
</td></tr></table>-->
</center><br><br>
</form>
</body>
<?php include("footer.php"); ?>

