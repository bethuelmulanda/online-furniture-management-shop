<style>
     .intabular
    {
     -webkit-border-radius: 10px;
-moz-border-radius: 10px;
   background-color:White;
    }
    </style>



<html>
<body>
<form>
<table width="90%" height="8%" align="center" border="1px">
<tr>
<td class="intabular" align="right" style="background-color:brown;color:white"><font size="4.5"><b>Project developed by:- BETHUEL MULANDA
</font></b></td>
</tr>
</table>
</form>
</body>
</html>