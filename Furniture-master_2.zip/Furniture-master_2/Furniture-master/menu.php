<?
<head>
	<link rel="stylesheet" href="css/CSS3 Menu_files/css3menu1/style.css" type="text/css" /><style type="text/css">._css3m{display:none}</style>
	
</head>
<body>
<table align="center" width="90%" >
<tr>
<td width="100%" height="100%">

<ul id="css3menu1" class="topmenu">
	<li class="topfirst"><a href="main.php" style="height:18px;line-height:18px;">Home</a></li>
	<li class="toplast"><a href="ProdView.php" style="height:18px;line-height:18px;">Shop New Products</a></li>
	<li class="toplast"><a href="usedProdview.php" style="height:18px;line-height:18px;">Shop Used Products</a></li>
    <li class="topmenu"><a href="payment.php" style="height:18px;line-height:18px;">View Cart</a></li>
	 <li class="topmenu"><a href="signout.php" style="height:18px;line-height:18px;">Logout</a>
	 </li>
	 
	</ul>
</td>
</tr>
</table>
</body>
</html>
?>