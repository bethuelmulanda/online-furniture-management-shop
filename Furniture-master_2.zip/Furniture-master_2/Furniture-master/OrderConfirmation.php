<html>
<head>
<title>Confirmation Page</title>
<link rel="stylesheet" href="css/CSS3 Menu_files/css3menu1/style.css" type="text/css" /><style type="text/css">._css3m{display:none}</style>
</head>
<?php include("header.php")?>
<?php include("header5.php")?>
<body background="b.png">
<!--<form> 
<table align="center" border="1.5" cellspacing="0" cellpadding="0" width="38%" height="38%" bgcolor="white">
<tr>
<td width="100%" height="50%"  color="black"><font size="5"><b>Thank you for your order....We will process your order as soon as possible
</font></b>
</td>
</tr>
</table>
</form>//-->
<form>
<table align="center" border="1" cellspacing="0" cellpadding="0" width="40%" height="40%"  >
<tr>
<td width="100%" width="100%"><img src="images/order.jpg">
</td>
</tr>
</table>
</form>
</body>
<?php include("footer.php"); ?>
</html>


