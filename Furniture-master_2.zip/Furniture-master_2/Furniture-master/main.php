<html>
<head>
<title>Main Page</title>
<link rel="stylesheet" href="css/CSS3 Menu_files/css3menu1/style.css" type="text/css" /><style type="text/css">._css3m{display:none}</style>
<table align="center" width="99%" >
<tr>
<td width="100%" height="99%">
<!--Testing new commit-->
<ul id="css3menu1" class="topmenu">
	
<li class="topfirst"><a href="adminlogin.php" style="height:18px;line-height:18px;">Admin Login</a></li>
	<li class="topfirst"><a href="reg.php" style="height:18px;line-height:18px;">Register</a></li>
	<li class="topfirst"><a href="login.php" style="height:18px;line-height:18px;">Customer Login</a></li>
	<li class="topfirst"><a href="prodview.php" style="height:18px;line-height:18px;">Shop By Category</a></li>
	
</ul>
</td>
</tr>
</table>
<form>
<table align="center" width="99%" height="70%">
<tr>
<td width="100%" height="100%">
<center><img class="intabular" src="images/banner.jpeg" width="100%" height="100%" name="image" border="1px" ></center>
</td>
</tr>
</table>
</form>
<style>

</style>
</head>
<br>
<body background="b.png">

<form>
<table width="99%" height="8%"  border="1px" align="center">
<tr>
<td class="intabular" align="right" style="background-color:brown; color:white"><font size="4.5"><b>Project developed by:-Bethuel Mulanda
</font></b></td>
</tr>
</table>
</form>
</body>
</html>

</html>
